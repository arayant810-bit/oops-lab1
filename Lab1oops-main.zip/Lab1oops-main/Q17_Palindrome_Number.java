import java.util.Scanner;

public class Q17_Palindrome_Number {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter an integer: ");
        int number = sc.nextInt();

        int original = number;
        int reverse = 0;

        if (number < 0) {
            System.out.println("Negative numbers are not considered here.");
        } else {
            while (number != 0) {
                int digit = number % 10;
                reverse = reverse * 10 + digit;
                number /= 10;
            }

            if (original == reverse)
                System.out.println(original + " is a palindrome.");
            else
                System.out.println(original + " is not a palindrome.");
        }

        sc.close();
    }
}
